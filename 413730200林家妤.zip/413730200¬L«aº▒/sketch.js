function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  noFill()
  stroke("#FF9797")  //線條顏色
  strokeWeight(1)   //線條粗細
  textSize(32);
  text("413730200林家妤", mouseX, mouseY);


  

  
  //=========宣告變數
  var rect_width = 50
  var bc_w = 50
  var sc_w = 25
  
 
  
  rectMode(CENTER)
  //第一排
  for(let x=0;x<width;x=x+rect_width){
    ellipse(x,25+50*0,bc_w)
    rect(x,25+50*0,rect_width)
    ellipse(25+x+rect_width,50+50*0,sc_w )  
  }

  //第二排
  for(let x=0;x<width;x=x+rect_width){
    ellipse(x,25+50*1,bc_w)
    rect(x,25+50*1,rect_width)
    ellipse(25+x+rect_width,50+50*1,sc_w )  
  }

  //======================使用迴圈，產生30排==========================
  for(let j=0;j<25;j=j+1){
    for(let x=0;x<width;x=x+rect_width){
      ellipse(x,25+50*j,bc_w)
      rect(x,25+50*j,rect_width)
      ellipse(25+x+rect_width,50+50*j,sc_w )
    }

  }
 

}


